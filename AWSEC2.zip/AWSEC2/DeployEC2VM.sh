#!/bin/bash

# Function to prompt for user input and create terraform.tfvars file
create_tfvars() {
  echo "Please enter the following information for Terraform configuration:"

  read -p "Enter AWS region: " aws_region
  read -p "Enter AWS access key: " aws_access_key
  read -sp "Enter AWS secret key: " aws_secret_key
  echo
  read -p "Enter AMI ID: " ami
  read -p "Enter Instance type: " instance_type
  read -p "Enter Instance name: " instance_name

  # Create terraform.tfvars file
  cat <<EOF > terraform.tfvars
aws_region    = "$aws_region"
aws_access_key = "$aws_access_key"
aws_secret_key = "$aws_secret_key"
ami_id           = "$ami"
instance_type = "$instance_type"
instance_name = "$instance_name"
EOF

  echo "terraform.tfvars file has been created."
}

# Run the function to create terraform.tfvars
create_tfvars
