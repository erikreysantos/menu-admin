#!/bin/bash

# Prompt for user inputs
read -p "Enter vSphere username: " vsphere_user
read -sp "Enter vSphere password: " vsphere_password
echo
read -p "Enter vSphere server: " vsphere_server
read -p "Enter datacenter: " datacenter
read -p "Enter cluster: " cluster
read -p "Enter datastore: " datastore
read -p "Enter network: " network
read -p "Enter template name: " template_name
read -p "Enter VM name: " vm_name
read -p "Enter VM IP: " vm_ip
read -p "Enter VM gateway: " vm_gateway

# Create terraform.tfvars file
cat <<EOF > terraform.tfvars
vsphere_user       = "$vsphere_user"
vsphere_password   = "$vsphere_password"
vsphere_server     = "$vsphere_server"
datacenter         = "$datacenter"
cluster            = "$cluster"
datastore          = "$datastore"
network            = "$network"
template_name      = "$template_name"
vm_name            = "$vm_name"
vm_ip              = "$vm_ip"
vm_gateway         = "$vm_gateway"
EOF

echo "terraform.tfvars file has been created."
