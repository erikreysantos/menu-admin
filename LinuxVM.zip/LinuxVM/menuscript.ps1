# PowerShell script to create terraform.tfvars
$vsphere_user = "erikreysantos@solaireresort.com"
$vsphere_password = Read-Host -Prompt "Enter vSphere password" -AsSecureString | ConvertFrom-SecureString
$vsphere_server = "snplvct1.solaireresort.com"
$datacenter = "SN-PROD-DC"
$cluster = "SN-PROD-CL"
$datastore = "SOLN-NX8155N-G8-PRIMARY-CONTAINER"
$network = "SOLN Prod SMS dPG 224"
$template_name = "Ubuntu-VM"
$vm_name = "Ubuntu-Server"
$vm_ip = "10.24.24.230"
$vm_gateway = "10.24.24.1"

# Writing to terraform.tfvars file
$terraformVars = @"
vsphere_user     = "$vsphere_user"
vsphere_password = "$vsphere_password"
vsphere_server   = "$vsphere_server"
datacenter       = "$datacenter"
cluster          = "$cluster"
datastore        = "$datastore"
network          = "$network"
template_name    = "$template_name"
vm_name          = "$vm_name"
vm_ip            = "$vm_ip"
vm_gateway       = "$vm_gateway"
"@

$terraformVars | Out-File -FilePath "./terraform.tfvars" -Force
Write-Host "terraform.tfvars file has been created."
