#!/bin/bash

# Function to display the menu
show_menu() {
    echo "VM Creation Menu"
    echo "1. Create VM in vSphere"
    echo "2. Exit"
}

# Function to prompt for user input
prompt() {
    local prompt_message=$1
    read -p "$prompt_message: " user_input
    echo $user_input
}

# Function to create an Ansible playbook for VM creation
create_playbook() {
    local vcenter_hostname="$1"
    local vcenter_username="$2"
    #local vcenter_password="K33pm31nf0rm3d!24x7001"
    local vm_name="$4"
    #local vm_datacenter="SN-PROD-DC"
    #local vm_cluster="SN-PROD-CL"
    #local vm_datastore="SOLN-NX8155N-G8-PRIMARY-CONTAINER"
    #local vm_network="SOLN Prod SMS dPG 224"
    #local vm_template="WINSQL2022TEMPLATE"
    #local vm_folder="Test"
    #local vm_disk_size="150"

    cat <<EOF > create_vm.yml
---
- name: Create VM in vSphere
  hosts: localhost
  gather_facts: no
  collections:
    - community.vmware

  vars:
    vcenter_hostname: "$vcenter_hostname"
    vcenter_username: "$vcenter_username"
    vcenter_password: "K33pm31nf0rm3d!24x7001"
    vm_name: "$vm_name"
    vm_datacenter: "SN-PROD-DC"
    vm_cluster: "SN-PROD-CL"
    vm_datastore: "SOLN-NX8155N-G8-PRIMARY-CONTAINER"
    vm_network: "SOLN Prod SMS dPG 224"
    vm_template: "WINSQL2022TEMPLATE"
    vm_folder: "Test"
    vm_disk_size: "150"

  tasks:
    - name: Create VM from template
      vmware_guest:
        hostname: "{{ vcenter_hostname }}"
        username: "{{ vcenter_username }}"
        password: "{{ vcenter_password }}"
        validate_certs: no
        name: "{{ vm_name }}"
        state: poweredon
        template: "{{ vm_template }}"
        datacenter: "{{ vm_datacenter }}"
        cluster: "{{ vm_cluster }}"
        datastore: "{{ vm_datastore }}"
        folder: "{{ vm_folder }}"
        networks:
          - name: "{{ vm_network }}"
        hardware:
          memory_mb: 2048
          num_cpus: 2
        disk:
          - size_gb: "{{ vm_disk_size }}"
            datastore: "{{ vm_datastore }}"
            type: thin
      delegate_to: localhost
EOF
}

# Main script loop
while true; do
    show_menu
    read -p "Enter your choice [1-2]: " choice

    case $choice in
        1)
            echo "Input Details for your VM"
            vcenter_hostname=$(prompt "Enter vCenter Hostname")
            vcenter_username=$(prompt "Enter vCenter Username")
            #vcenter_password=$(prompt "Enter vCenter Password")
            vm_name=$(prompt "Enter VM Name")
            #vm_datacenter=$(prompt "Enter Datacenter Name")
            #vm_cluster=$(prompt "Enter Cluster Name")
            #vm_datastore=$(prompt "Enter Datastore Name")
            #vm_network=$(prompt "Enter Network Name")
            #vm_template=$(prompt "Enter Template Name")
            #vm_folder=$(prompt "Enter Folder Name")
            #vm_disk_size=$(prompt "Enter Disk Size in GB")

            # Create the Ansible playbook
            create_playbook "$vcenter_hostname" "$vcenter_username" "$vcenter_password" "$vm_name" "$vm_datacenter" "$vm_cluster" "$vm_datastore" "$vm_network" "$vm_template" "$vm_folder" "$vm_disk_size"

            echo "Ansible playbook created: create_vm.yml"

            # Run the Ansible playbook
            ansible-playbook create_vm.yml
            ;;
        2)
            echo "Exiting. Goodbye!"
            exit 0
            ;;
        *)
            echo "Invalid choice. Please select a number between 1 and 2."
            ;;
    esac

    echo
done
